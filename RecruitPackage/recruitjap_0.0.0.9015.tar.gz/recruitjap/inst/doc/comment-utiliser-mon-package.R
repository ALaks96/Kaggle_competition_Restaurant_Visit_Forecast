## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(recruitjap)

## ------------------------------------------------------------------------
path_air_data <- system.file("cleaned_csv","air_data.csv", package = "recruitjap")
test <- read.csv(path_air_data)
test <- vday_transf(test)

## ------------------------------------------------------------------------
test <- vyear_transf(test)

## ------------------------------------------------------------------------
test <- vdayweek_transf(test)

## ------------------------------------------------------------------------
test <- lat_transf(test)
test <- lon_transf(test)

## ------------------------------------------------------------------------
test <- vholflg_transf(test)

## ------------------------------------------------------------------------
test <- vmonth_transf(test)

## ------------------------------------------------------------------------
path_complete_data <- system.file("cleaned_csv", "complete_data.csv", package = "recruitjap")
try <- read.csv(path_complete_data)

## ------------------------------------------------------------------------
try <- ryear_transf(try)

## ------------------------------------------------------------------------
try <- rholflg_transf(try)

## ------------------------------------------------------------------------
try <- rday_transf(try)

## ------------------------------------------------------------------------
try <- rdayweek_transf(try)

## ------------------------------------------------------------------------
try <- rtime_transf(try)

## ------------------------------------------------------------------------
try <- rmonth_transf(try)

## ------------------------------------------------------------------------
test <- read.csv(path_air_data)

## ------------------------------------------------------------------------
test <- area_transf(test)

## ------------------------------------------------------------------------
test <- genre_gr_transf(test)

## ------------------------------------------------------------------------
test <- bme_vmonth_transf(test)

## ------------------------------------------------------------------------
test <- barrest_transf(test)

## ------------------------------------------------------------------------
test <- goldw_transf(test)

## ------------------------------------------------------------------------
test <- goldd_transf(test)

## ------------------------------------------------------------------------
test <- wknd_transf(test)

## ------------------------------------------------------------------------
test <- wealth_transf(test)

## ------------------------------------------------------------------------
try <- read.csv(path_complete_data)

## ------------------------------------------------------------------------
try <- dn_transf(try)

## ------------------------------------------------------------------------
try <- latency_transf(try)

## ------------------------------------------------------------------------
try <- bme_rmonth_transf(try)

## ------------------------------------------------------------------------
#Load feature engineered file:
dir_pred <- system.file("formatted_csv","data_1h_xgb.csv", package = "recruitjap")
data_feature <- read.csv(dir_pred)

#save a copy:
data_c <- data_feature


## ------------------------------------------------------------------------
#do test train split:
list_train_train <- test_train(data_feature)
#get the values out of the list:
data <- list_train_train[["data"]]
TEST <- list_train_train[["TEST"]]
TRAIN <- list_train_train[["TRAIN"]]

## ------------------------------------------------------------------------
#call input function:
list_input <- xgboost_input(TEST,TRAIN)
#get the values out of the list:
dTRAIN <- list_input[["dTRAIN"]]
dTEST <- list_input[["dTEST"]]

## ------------------------------------------------------------------------
#fix the parameters:
eta <- 0.3
gamma <- 0
max_depth <- 20
min_child_weight <- 1
subsample <- 1
colsample_bytree <- 1

#call output function with the parameters defined above:
xgb1 <- xgboost_output(dTRAIN,eta,gamma,max_depth,min_child_weight,subsample,colsample_bytree)

## ------------------------------------------------------------------------
#call predict function:
xgbpred <- xgboost_predict(xgb1,dTEST)

## ------------------------------------------------------------------------
#call evaluation function for Root Mean Squared Logarithmic Error (RMSLE):
rmlse_fun(xgbpred,TEST$target)

## ------------------------------------------------------------------------
# graph_dif(xgbpred,50000)

## ------------------------------------------------------------------------
#load sample sumission file:
dir_sub <- system.file("formatted_csv","data_1h_xgb_samplesubmission.csv", package = "recruitjap")
sample <- read.csv(dir_sub)

#initialize data:
data <- data_c


#delete the difference in the 2 data frames call the same_features function for this:
new_data <- same_features(data,sample)
#assign the values:
data <- new_data[["data"]]
sample <- new_data[["sample"]]

## ------------------------------------------------------------------------
#save id and date into id_date:
id_data <- sample %>%
  dplyr::select(id,visit_date)
#delete visit_data and id:
sample <- sample %>%
  dplyr::select(-c(visit_date,id)) %>%
  dplyr::rename(target = visitors)
#rename to target:
data <- data %>%
  dplyr::rename(target = visitors)


id_visit_date <- data %>%
  dplyr::select(id,visit_date)
visitors <- data %>%
  dplyr::select(target)
#delete id and visit_date, this will also be our function output:
data <- data %>%
  dplyr::select(-c(id,visit_date))

#bring the 2 dataframes in the same order!
col_order <- colnames(data)
sample <- sample[,col_order]


#get rid of window matrix, we need to fill it up recursively later on in a second step:
sample <- sample[,1:99]
data <- data[,1:99]

## ------------------------------------------------------------------------
#call input function:
list_input <- xgboost_input(sample,data)
#get the values out of the list:
dTRAIN <- list_input[["dTRAIN"]]
dTEST <- list_input[["dTEST"]]

#call output function with the parameters defined above:
xgb1 <- xgboost_output(dTRAIN,eta,gamma,max_depth,min_child_weight,subsample,colsample_bytree)

#call predict function:
xgbpred <- xgboost_predict(xgb1,dTEST)

#the parameters do not need to be redefined, as they stay the same


xgbpred <- data.frame(xgbpred)

p <- data.frame(paste(id_data$id,sep="_",id_data$visit_date))

submission_file <-cbind(p,xgbpred)
#View(submission_file)

colnames(submission_file) <- c("id","visitors")

## To Write it:
#
# write.csv(submission_file, file="data/sub.csv",row.names = FALSE)
#
#
# sub <- read.csv("data/sub.csv")
# View(sub)

## ------------------------------------------------------------------------
# recruitjap::shinyapp()

